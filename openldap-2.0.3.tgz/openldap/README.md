# OpenLDAP

## TL;DR

```console
$ helm repo add robobee-repos https://github.com/robobee-repos/helm-charts/
$ helm install my-release robobee-repos/openldap
```
## License

Copyright &copy; 2022 Erwin Müller
Copyright &copy; 2022 Bitnami

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
